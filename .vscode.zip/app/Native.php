<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Native extends Model
{
   
     public $table = 'natives';
    protected $fillable = [
        'native_id', 'native_name',
    ];
}
