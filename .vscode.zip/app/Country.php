<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    public $table = 'country';
    protected $fillable = [
        'country_id', 'country_name', 'country_code',
    ];
}
