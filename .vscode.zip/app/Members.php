<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Members extends Model
{
    //
    protected $dates = [
        'created_at',
        'updated_at',
        
    ];


     protected $fillable = [
          'user_id', 'unique_id', 'town', 'rcenter', 'country', 'native', 'firstname', 'midname', 'surname', 'gender', 'email', 'birthday', 'bloodgroup', 'mobile', 'marital', 'boxno', 'pcode', 'pwork', 'business', 'address', 'family_code', 'pbhno', 'nation_code', 'pbhconfirm', 'inv_status', 'user_code', 'bureau', 'insurance', 'attend', 'sports', 'cultural', 'accomodation', 'payment_id', 'sports_registered', 'photo_url',
    ];

    public $table = 'members';

    public function Rcenter()
    {
        return $this->hasOne('App\Center', 'center_id', 'rcenter');
    }

     public function Native()
    {
        return $this->hasOne('App\Native', 'native_id', 'native');
    }
    public function County()
    {
        return $this->hasOne('App\Country', 'country_id', 'sports_registered');
    }
    
    public function Sport()
    {
        return $this->hasOne('App\Sport', 'sport_id', 'sports_registered');
    }
     public function Town()
    {
        return $this->hasOne('App\Town', 'town_id', 'town');
    }

    

}
