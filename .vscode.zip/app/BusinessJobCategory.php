<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BusinessJobCategory extends Model
{
    protected $dates = [
        'created_at',
        'updated_at',
       
        
    ];
    protected $fillable = [
        'cat_id', 'bus_job', 'cat_name',
    ];

    public $table = 'business_job_categories';

   
}
