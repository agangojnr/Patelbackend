<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Center extends Model
{
    public $table = 'centers';
    protected $fillable = [
        'center_id', 'center_name', 'country_id', 'center_code', 'assigned'
    ];


 public function country()
    {
        return $this->hasOne('App\Country', 'country_id', 'country_id');
    }

}
