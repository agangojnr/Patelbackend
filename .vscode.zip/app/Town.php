<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Town extends Model
{
   public $table = 'towns';
    protected $fillable = [
        'town_id', 'town_name', 'center_id', 'town_code'
    ];

public function centre()
    {
        return $this->hasOne('App\Center', 'center_id', 'center_id');
    }

}
