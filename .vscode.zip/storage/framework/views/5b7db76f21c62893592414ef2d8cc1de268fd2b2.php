<div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-6">
        <div class="copyright text-center text-xl-left text-muted">
            &copy; <?php echo e(now()->year); ?> <a href="http://www.saasmonks.in/" class="font-weight-bold ml-1"
                target="_blank">Technoguru Digital SYstems</a> &amp;
            <a class="font-weight-bold ml-1" target="_blank" href="">Team</a>
        </div>
    </div>
    
</div><?php /**PATH C:\xampp\htdocs\patelnew\resources\views/layouts/footers/nav.blade.php ENDPATH**/ ?>