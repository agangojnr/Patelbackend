

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.header',
array(
'class'=>'info',
'title'=>"Business Job",'description'=>'',
'icon'=>'fas fa-home',
'breadcrumb'=>array([
'text'=>'Business And Jobs'
])), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt--7">
    <div class="row">
        <div class="col">
            <div class="card shadow">
                <div class="card-header mb-3">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Business Jobs')); ?></h3>
                        </div>
                       
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('businessjob.create')); ?>"
                                class="btn btn-sm btn-info"><?php echo e(__('Add Business Or  Jobs')); ?></a>
                        </div>
                       
                    </div>
                </div>

                <div class="col-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('status')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="table-responsive">
                    <table id="dataTable" class="table table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
                                <th><?php echo e(__('Title')); ?></th>
                                <th><?php echo e(__('Short Description')); ?></th>
                                <th><?php echo e(__('Long Description')); ?></th>
                                 <th><?php echo e(__('Experience')); ?></th>
                                <th><?php echo e(__('Contact')); ?></th>
                                <th><?php echo e(__('Email')); ?></th>
                                <th><?php echo e(__('Business Or Job')); ?></th>
                                <th><?php echo e(__('Action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $businessjob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($cat->title); ?> </td>
                                 <td><?php echo e($cat->short_description); ?> </td>
                                <td><?php echo $cat->long_decription; ?></td>
                                 <td><?php echo e($cat->experience); ?> </td>
                                 <td> <?php echo e($cat->phone_number); ?></td>
                                
                                <td> <?php echo e($cat->email_address); ?></td>
                                <td>
                                    <?php if($cat->bus_job_id==1): ?>
                                    <span class="badge   badge-success m-1"><?php echo e(__('Job')); ?></span>
                                    <?php else: ?>
                                    <span class="badge   badge-warning  m-1"><?php echo e(__('Business')); ?></span>

                                    <?php endif; ?>
                                </td>
                                <td class="d-flex">


                                    <a class="btn btn-sm btn-outline-default btn-icon m-1"
                                        href="<?php echo e(route('branch.show', $cat->bus_job_id)); ?>">
                                        <span class="ul-btn__icon"><i class="far fa-eye"></i></span>
                                    </a>
                                    
                                    <a class="btn btn-sm btn-outline-info btn-icon m-1"
                                        href="<?php echo e(route('branch.edit', $cat->bus_job_id)); ?>">
                                        <span class="ul-btn__icon"><i class="fas fa-pencil-alt"></i></span>
                                    </a>
                                

                                    <form action="<?php echo e(route('branch.destroy', $cat->bus_job_id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="button" class="btn btn-sm btn-outline-danger btn-icon m-1"
                                            onclick="confirm('<?php echo e(__("Are you sure you want to delete this?")); ?>') ? this.parentElement.submit() : ''">
                                            <span class="ul-btn__icon"><i class="far fa-trash-alt"></i></span>
                                        </button>
                                    </form>

                                   
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/travell5/public_html/patel/resources/views/admin/businessjob/index.blade.php ENDPATH**/ ?>