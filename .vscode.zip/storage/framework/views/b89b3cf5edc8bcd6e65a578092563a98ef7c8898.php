
<?php $__env->startPush('css'); ?>
<link type="text/css" href="<?php echo e(asset('argon')); ?>/css/invoice.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.headers.header',
array(
'class'=>'info',
'title'=>"Booking",'description'=>'',
'icon'=>'fas fa-home',
'breadcrumb'=>array([
'text'=>'Booking List',
'text'=>'Booking',
])), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid mt--7">
    <div class="row">
        <div class="col">
            <div class="card shadow">
                <div class="card-header mb-3">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Booking')); ?></h3>
                        </div>
                        <div class="col-4 text-right">
                            <a class="btn btn-sm btn-primary text-white"
                                onclick="printDiv('#printableArea')"><?php echo e(__('Print')); ?></a>
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('status')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="invoice-box" id="printableArea">
                    <table cellpadding="0" cellspacing="0">
                        <tr class="top">
                            <td colspan="2">
                                <table>
                                    <tr>
                                        <td class="title">
                                            <img src="<?php echo e(asset('upload') .'/'.$bookingMaster->branch->icon); ?>"
                                                style="width:100%; max-width:125px;">
                                        </td>

                                        <td>
                                            Invoice #: <?php echo e($bookingMaster->booking_id); ?><br>
                                            Start Time: <?php echo e($bookingMaster->start_time->format('F d,Y h:m A')); ?><br>
                                            End Time: <?php echo e($bookingMaster->end_time->format('F d,Y h:m A')); ?><br>
                                            Status: <b> <?php if($bookingMaster->status == 1): ?>
                                            <?php echo e(__('Confirm')); ?>

                                            <?php elseif($bookingMaster->status == 0): ?>
                                            <?php echo e(__('Waiting')); ?>

                                            <?php elseif($bookingMaster->status == 2): ?>
                                            <?php echo e(__('Complete')); ?>

                                            <?php else: ?>
                                            <?php echo e(__('Cancel')); ?>

                                            <?php endif; ?>
                                            </b>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>

                        <tr class="information">
                            <td colspan="2">
                                <table>
                                    <tr>
                                        <td>
                                            <?php echo e($bookingMaster->branch->name); ?><br>
                                            <?php echo e($bookingMaster->branch->address); ?><br>

                                        </td>

                                        <td>
                                            <?php echo e($bookingMaster->user->name); ?><br>
                                            <?php echo e($bookingMaster->user->email); ?><br>

                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>

                        <tr class="heading">
                            <td>
                                Payment Method
                            </td>

                            <td>
                                Payment Status
                            </td>
                        </tr>

                        <tr class="details">
                            <td>
                                <?php echo e($bookingMaster->payment_method); ?> <br>
                                <?php echo e($bookingMaster->payment_token); ?>

                            </td>

                            <td>
                                <?php echo e($bookingMaster->payment_status == 0 ? 'Un-Paid' : 'Paid'); ?>

                            </td>
                        </tr>

                        <tr class="heading">
                            <td>
                                Service (Employee)
                            </td>
                        
                            <td>
                                Duration
                            </td>
                        </tr>
                        <?php $__currentLoopData = $bookingMaster->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr class="item">
                            <td>
                                <?php echo e($item->service->name); ?> (<?php echo e($item->employee->name); ?>)
                            </td>

                            <td>
                                <?php echo e($item->duration); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <tr class="">
                            <td></td>

                            <td>
                                Discount: <?php echo e($bookingMaster->currency); ?><?php echo e($bookingMaster->discount); ?>

                            </td>
                        </tr>
                        <tr class="total">
                            <td></td>

                            <td>
                                Total:<?php echo e($bookingMaster->currency); ?><?php echo e($bookingMaster->total); ?>

                            </td>
                        </tr>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>
<script>
    function printDiv(divName) {
// var printContents = document.getElementById(divName).innerHTML;
// var originalContents = document.body.innerHTML;
Popup($('<div />').append($(divName).clone()).html());
// document.body.innerHTML = printContents;

// window.print();

document.body.innerHTML = originalContents;
}
function Popup(data) 
{
    var mywindow = window.open('', 'my div', 'height=400,width=600');
    mywindow.document.write('<html><head><title>my div</title>');
     mywindow.document.write('<link type="text/css" href="<?php echo e(asset('argon')); ?>/css/invoice.css" rel="stylesheet" />');
    mywindow.document.write('</head><body >');
    mywindow.document.write(data);
    mywindow.document.write('</body></html>');
setTimeout(() => {
    mywindow.print();
    
}, 2000);
  //  mywindow.close();

    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara\beatybella\resources\views/admin/booking/show.blade.php ENDPATH**/ ?>