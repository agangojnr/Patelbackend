

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.header',
array(
'class'=>'info',
'title'=>"Sub Categories",'description'=>'',
'icon'=>'fas fa-home',
'breadcrumb'=>array([
'text'=>'Sub Category List'
])), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt--7">
    <div class="row">
        <div class="col">
            <div class="card shadow">
                <div class="card-header mb-3">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Sub Category')); ?></h3>
                        </div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('subcategory_create')): ?>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('subcategories.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add new')); ?></a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('status')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="table-responsive">
                    <table id="dataTable" class="table table-flush" style="width:100%">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
                                <th><?php echo e(__('Name')); ?></th>
                                <th><?php echo e(__('Category')); ?></th>
                                <th><?php echo e(__('Description')); ?></th>
                                <th><?php echo e(__('Price')); ?></th>
                                <th><?php echo e(__('Service For')); ?></th>
                                <th><?php echo e(__('Duration (min)')); ?></th>
                                <th><?php echo e(__('Preparation Time (min)')); ?></th>
                               
                                <th><?php echo e(__('Status')); ?></th>
                                <th><?php echo e(__('Action')); ?></th>
                            
                            </tr>
                        </thead>
                   <tbody>
            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($subcategory->name); ?>

                        <?php if($subcategory->is_best): ?>
                
                        <a href="#" class="badge badge-danger m-2 p-2"><?php echo e(__('BEST')); ?></a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e($subcategory->category->name); ?>

                    </td>
                   
                    <td>
                        <?php echo e($subcategory->description); ?>

                    </td>
                    <td>
                      <?php echo e($subcategory->currency); ?><?php echo e($subcategory->price); ?>

                    </td>
                  
                    <td>
                     
                        <?php if($subcategory->for_who == 0): ?>
                        
                        <span  class="badge badge-primary m-2 p-2"><?php echo e(__('Man & Women')); ?></span>
                        <?php elseif($subcategory->for_who == 1): ?>
                        <span class="badge badge-danger m-2 p-2"><?php echo e(__('Women')); ?></span>
                        <?php else: ?> 
                        <span class="badge badge-default m-2 p-2"><?php echo e(__('Man')); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e($subcategory->duration); ?>

                    </td>
                    <td>
                        <?php echo e($subcategory->preparation_time); ?>

                    </td>
                    
                    <td>
                        <?php if($subcategory->status): ?>
                        <span class="badge  badge-success m-1"><?php echo e(__('Active')); ?></span>
                        <?php else: ?>
                        <span class="badge  badge-warning  m-1"><?php echo e(__('Disabled')); ?></span>
                
                        <?php endif; ?>
                    </td>
                    <td class="d-flex">
                
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('subcategory_edit')): ?>
                        <a class="btn btn-outline-info btn-icon m-1 btn-sm" href="<?php echo e(route('subcategories.edit', $subcategory->id)); ?>">
                            <span class="ul-btn__icon"><i class="fas fa-pencil-alt"></i></span>
                        </a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('subcategory_delete')): ?>
                
                        <form action="<?php echo e(route('subcategories.destroy', $subcategory)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="button" class="btn btn-outline-danger btn-icon m-1 btn-sm"
                                onclick="confirm('<?php echo e(__("Are you sure you want to delete this?")); ?>') ? this.parentElement.submit() : ''">
                                <span class="ul-btn__icon"><i class="far fa-trash-alt"></i></span>
                            </button>
                        </form>
                
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara\beatybella\resources\views/admin/subcategories/index.blade.php ENDPATH**/ ?>