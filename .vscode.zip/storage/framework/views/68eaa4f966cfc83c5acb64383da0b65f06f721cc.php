<form enctype="multipart/form-data" action="<?php echo e(route('twilio.update')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row mb-3">


        <div class="col-2 mt-3">
            <h5> <?php echo e(__('SMS/User Verification')); ?></h5>

        </div>
        <div class="col-4 mt-3 pr-0">
            <label class="switch switch-success mr-3">
                <span> <?php echo e(__('')); ?></span>
                <input type="checkbox" value="1" name="verification" <?php echo e($master['verification'] ?? 0 ? 'checked' : ''); ?>>
                <span class="slider"></span>
            </label>


        </div>
        <div class="col-6 mt-3">
            <label class="radio radio-primary">
                <input type="radio" name="sms_gateway" <?php echo e($master['sms_gateway'] === 'twilio' ?? 0 ? 'checked' : ''); ?>

                    value="twilio">
                <span>TWILIO</span>
                <span class="checkmark"></span>
            </label>
            <label class="radio radio-secondary">
                <input type="radio" name="sms_gateway" <?php echo e($master['sms_gateway'] ==='textLocal' ?? 0 ? 'checked' : ''); ?>

                    value="textLocal">
                <span>TextLocal</span>
                <span class="checkmark"></span>
            </label>

        </div>


        <div class="form-group col-6 mb-4">
            <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('COUNTRY_CODE')); ?></label>
            <input type="text" name="country_code" class="form-control  <?php $__errorArgs = ['country_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="<?php echo e(__('Please Enter Admin %')); ?>" required min="1" value="<?php echo e($master['country_code'] ?? ''); ?>">
            <?php $__errorArgs = ['country_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-div"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
        <div class="form-group col-6 mb-4">
            <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('TWILIO_NUMBER')); ?></label>
            <input type="text" name="TWILIO_NUMBER"
                class="form-control  <?php $__errorArgs = ['TWILIO_NUMBER'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="<?php echo e(__('Please Enter Admin %')); ?>" required min="1"
                value="<?php echo e($master['TWILIO_NUMBER'] ?? ''); ?>">
            <?php $__errorArgs = ['TWILIO_NUMBER'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-div"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
        <div class="form-group col-6 mb-4">
            <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('TWILIO_SID')); ?></label>
            <div class="input-group">
                <input type="password" name="TWILIO_SID"
                    class="form-control  <?php $__errorArgs = ['TWILIO_SID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="<?php echo e(__('Please Enter Admin %')); ?>" required min="1"
                    value="<?php echo e($master['TWILIO_SID'] ?? ''); ?>">
                <div class="input-group-append">
                    <span class="input-group-text bg-transparent pointer" onclick="toggleInput('TWILIO_SID')">
                        <i class="far fa-eye"></i>
                    </span>
                </div>
            </div>
            <?php $__errorArgs = ['TWILIO_SID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-div"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
        <div class="form-group col-6 mb-4">
            <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('TWILIO_AUTH_TOKEN')); ?></label>
            <div class="input-group">
                <input type="password" name="TWILIO_AUTH_TOKEN"
                    class="form-control  <?php $__errorArgs = ['TWILIO_AUTH_TOKEN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="<?php echo e(__('Please Enter Admin %')); ?>" required min="1"
                    value="<?php echo e($master['TWILIO_AUTH_TOKEN'] ?? ''); ?>">
                <div class="input-group-append">
                    <span class="input-group-text bg-transparent pointer" onclick="toggleInput('TWILIO_AUTH_TOKEN')">
                        <i class="far fa-eye"></i>
                    </span>
                </div>
            </div>
            <?php $__errorArgs = ['TWILIO_AUTH_TOKEN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-div"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
        <div class="form-group col-6 mb-4">
            <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('TEXT_LOCAL_API')); ?></label>
            <div class="input-group">
                <input type="password" name="TEXT_LOCAL_API"
                    class="form-control  <?php $__errorArgs = ['TEXT_LOCAL_API'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="<?php echo e(__('Please Enter Admin %')); ?>" required min="1"
                    value="<?php echo e($master['TEXT_LOCAL_API'] ?? ''); ?>">
                <div class="input-group-append">
                    <span class="input-group-text bg-transparent pointer" onclick="toggleInput('TEXT_LOCAL_API')">
                        <i class="far fa-eye"></i>
                    </span>
                </div>
            </div>
            <?php $__errorArgs = ['TEXT_LOCAL_API'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-div"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
    </div>
    <div class="card-footer bg-transparent">
        <div class="mc-footer">
            <div class="row">
                <div class="col-lg-12 text-right">
                    <button type="submit" class="btn btn-raised ripple btn-raised-primary m-1"><?php echo e(__('Submit')); ?></button>
                    <button type="reset"
                        class=" btn btn-raised ripple btn-raised-secondary m-1"><?php echo e(__('Reset')); ?></button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\vaxkenya\resources\views/admin/twilio/index.blade.php ENDPATH**/ ?>