<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.header',
array(
'class'=>'info',
'title'=>"Review",'description'=>'',
'icon'=>'fas fa-home',
'breadcrumb'=>array([
'text'=>'Review List'
])), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .activeStar {
        color: goldenrod
    }

</style>
<div class="container-fluid mt--7">
    <div class="row">
        <div class="col">
            <div class="card shadow">
                <div class="card-header mb-3">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0"><?php echo e(__('Review')); ?></h3>
                        </div>

                    </div>
                </div>
                <div class="card-header mb-3">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0"><?php echo e(__('Available Tag')); ?></h3>
                            <p class="mb-0 mt-0"><?php echo e(__('click to copy.')); ?></p>
                            <li class="list-group-item border-0">
                                <span class="badge badge-primary badge-own  r-badge text-18 copy" id="copy_1"
                                    onclick="copyToClipboard('copy_1')">{{user_name}}</span>



                            </li>
                        </div>

                    </div>
                </div>

                <div class="col-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('status')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="card-body pb-0">
                    <form method="POST" action="<?php echo e(route('custom.user')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row ">

                            <div class="form-group col-12 ">
                                <label for="inputEmail4" class="ul-form__label">
                                    <?php echo e(__('Notification Title')); ?></label>
                                <input type="text" name="title"
                                    class="form-control  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="<?php echo e(__('Please Enter Notification Title')); ?>" required min="1">
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-div"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="form-group col-12 ">
                                <label for="inputEmail4" class="ul-form__label">
                                    <?php echo e(__('Notification Subtitle')); ?></label>
                                <input type="text" name="sub_title"
                                    class="form-control  <?php $__errorArgs = ['sub_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="<?php echo e(__('Please Enter Notification Subtitle')); ?>" required min="1">
                                <?php $__errorArgs = ['sub_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-div"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group col-md-8">
                                <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('Users:')); ?></label>
                                <select class="form-control" name="users[]" multiple="multiple" id="users">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($user['id']); ?>"><?php echo e($user['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                                <?php $__errorArgs = ['users'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-div"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="form-group col-md-4 mt-4">
                                <button type="button" class="btn  btn-primary m-1"
                                    id="usersSelectAll"><?php echo e(__('Select All')); ?></button>
                                <button type="button" class="btn btn-secondary m-1"
                                    id="usersSelectDeAll"><?php echo e(__('Deselect All')); ?></button>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent">
                            <div class="mc-footer">
                                <div class="row">
                                    <div class="col-lg-12 text-right">
                                        <button type="submit" class="btn  btn-primary m-1"><?php echo e(__('Submit')); ?></button>
                                        <button type="reset" class=" btn  btn-secondary m-1"><?php echo e(__('Reset')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vaxkenya\resources\views/admin/customNotification/index.blade.php ENDPATH**/ ?>