

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.header',
array(
'class'=>'info',
'title'=>"Notification",'description'=>'',
'icon'=>'fas fa-home',
'breadcrumb'=>array([
'text'=>'Notification'
])), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .activeStar {
        color: goldenrod
    }
</style>
<div class="container-fluid mt--7">
    <div class="row">
        <div class="col">
            <div class="card shadow">
                <div class="card-header mb-3">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0"><?php echo e(__('Notification')); ?></h3>
                        </div>

                    </div>
                </div>
                <div class="card-header mb-3">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0"><?php echo e(__('Available Tag')); ?></h3>
                            <p class="mb-0 mt-0"><?php echo e(__('click to copy.')); ?></p>
                            <li class="list-group-item border-0">
                                <span class="badge badge-primary  r-badge text-18 copy" id="copy_1"
                                    onclick="copyToClipboard('copy_1')"
                                    style="text-transform:none">{{user_name}}</span>
                                <span class="badge badge-dark r-badge text-18 copy" id="copy_2"
                                    onclick="copyToClipboard('copy_2')" style="text-transform:none">{{branch_name}} </span>
                                <span class="badge badge-primary r-badge text-18 copy" id="copy_3"
                                    onclick="copyToClipboard('copy_3')" style="text-transform:none">{{booking_date}} </span>
                                <span class="badge badge-success r-badge text-18 copy" id="copy_4"
                                    onclick="copyToClipboard('copy_4')" style="text-transform:none">{{booking_id}} </span>


                            </li>
                        </div>

                    </div>
                </div>

                <div class="col-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('status')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="card-body pb-0">
                    <ul class="nav nav-pills nav-fill flex-column flex-sm-row mb-4" id="myTab" role="tablist">
                        <?php $__currentLoopData = $notis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li class="nav-item">
                            <a class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" id="home-basic-tab-<?php echo e($noti->id); ?>"
                                data-toggle="tab" href="#noti-<?php echo e($noti->id); ?>" role="tab" aria-controls="<?php echo e($noti->id); ?>"
                                aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>"><?php echo e($noti->for_what); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                    <div class="tab-content pb-0" id="myTabContent">
                        <?php $__currentLoopData = $notis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="noti-<?php echo e($noti->id); ?>"
                            role="tabpanel" aria-labelledby="home-basic-tab-<?php echo e($noti->id); ?>">
                            <form action="<?php echo e(route('notification.update',$noti->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row ">
                                    <div class="form-group col-12 ">
                                        <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('Title')); ?></label>
                                        <input type="text" name="for_what"
                                            class="form-control  <?php $__errorArgs = ['for_what'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="<?php echo e(__('Please Enter Admin %')); ?>" required min="1"
                                            value="<?php echo e($noti->for_what); ?>">
                                        <?php $__errorArgs = ['for_what'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                    <div class="form-group col-12 ">
                                        <label for="inputEmail4" class="ul-form__label">
                                            <?php echo e(__('Notification Title')); ?></label>
                                        <input type="text" name="title"
                                            class="form-control  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="<?php echo e(__('Please Enter Notification Title')); ?>" required min="1"
                                            value="<?php echo e($noti->title); ?>">
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="form-group col-12 ">
                                        <label for="inputEmail4" class="ul-form__label">
                                            <?php echo e(__('Notification Subtitle')); ?></label>
                                        <input type="text" name="sub_title"
                                            class="form-control  <?php $__errorArgs = ['sub_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="<?php echo e(__('Please Enter Notification Subtitle')); ?>" required min="1"
                                            value="<?php echo e($noti->sub_title); ?>">
                                        <?php $__errorArgs = ['sub_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="card-footer bg-transparent">
                                    <div class="mc-footer">
                                        <div class="row">
                                            <div class="col-lg-12 text-right">
                                                <button type="submit"
                                                    class="btn  btn-primary m-1"><?php echo e(__('Submit')); ?></button>
                                                <button type="reset"
                                                    class=" btn  btn-secondary m-1"><?php echo e(__('Reset')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function copyToClipboard(id) {
    var $body = document.getElementsByTagName('body')[0];
    var secretInfo = document.getElementById(id).innerHTML;
    var $tempInput = document.createElement('INPUT');
    $body.appendChild($tempInput);
    $tempInput.setAttribute('value', secretInfo)
    $tempInput.select();
    document.execCommand('copy');
    $body.removeChild($tempInput);
    alert('tag copy.')
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara\beatybella\resources\views/admin/staticNotification/index.blade.php ENDPATH**/ ?>