<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
        <!-- Toggler -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main"
            aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Brand -->
        <a class="navbar-brand pt-0" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('argon')); ?>/img/brand/blue.png" class="navbar-brand-img" alt="...">
        </a>
        <!-- User -->
        <ul class="nav align-items-center d-md-none">
            <li class="nav-item dropdown">
                <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                    aria-expanded="false">
                    <div class="media align-items-center">
                        <span class="avatar avatar-sm rounded-circle">
                            <img alt="Image placeholder" src="<?php echo e(asset('argon')); ?>/img/theme/team-1-800x800.jpg">
                        </span>
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
                    <div class=" dropdown-header noti-title">
                        <h6 class="text-overflow m-0"><?php echo e(__('Welcome!')); ?></h6>
                    </div>
                    <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item">
                        <i class="ni ni-single-02"></i>
                        <span><?php echo e(__('My profile')); ?></span>
                    </a>

                    <div class="dropdown-divider"></div>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                        <i class="ni ni-user-run"></i>
                        <span><?php echo e(__('Logout')); ?></span>
                    </a>
                </div>
            </li>
        </ul>
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
            <!-- Collapse header -->
            <div class="navbar-collapse-header d-md-none">
                <div class="row">
                    <div class="col-6 collapse-brand">
                        <a href="<?php echo e(route('home')); ?>">
                            <img src="<?php echo e(asset('argon')); ?>/img/brand/blue.png">
                        </a>
                    </div>
                    <div class="col-6 collapse-close">
                        <button type="button" class="navbar-toggler" data-toggle="collapse"
                            data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false"
                            aria-label="Toggle sidenav">
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </div>
            <!-- Form -->
            
        <!-- Navigation -->
        <ul class="navbar-nav">
            <h6 class="navbar-heading text-muted" style="padding: 0rem 1.5rem;">Navigation</h6>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">
                    <i class="fas fa-tachometer-alt text-primary"></i> <?php echo e(__('Dashboard')); ?>

                </a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">
                    <i class="far fa-id-badge text-blue"></i> <?php echo e(__('Role')); ?>

                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>

            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                    <i class="far fa-user text-blue"></i> <?php echo e(__('User')); ?>

                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category_access')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('categories.index')); ?>">
                    <i class="far fa-folder text-blue"></i> <?php echo e(__('Category')); ?>

                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('subcategory_access')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('subcategories.index')); ?>">
                    <i class="far fa-list-alt text-blue"></i> <?php echo e(__('Sub Category')); ?>

                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['employee_access','branch_employee_access'])): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('employee.index')); ?>">
                    <i class="fas fa-user-tie text-blue"></i> <?php echo e(__('Employee')); ?>

                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['branch_access','branch_manager_access'])): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('branch.index')); ?>">
                    <i class="fas fa-store-alt text-blue"></i> <?php echo e(__('Branch')); ?>

                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('offer_access')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('offers.index')); ?>">
                    <i class="fas fa-gift text-blue"></i> <?php echo e(__('Offers')); ?>

                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('appuser_access')): ?>
            <li class="nav-item">
                
                <a class="nav-link" href="<?php echo e(route('appuser.index')); ?>">
                    <i class="fas fa-shower text-blue"></i> <?php echo e(__('Customer')); ?>

                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['booking_access','branch_booking_access'])): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('booking.index')); ?>">
                    <i class="fas fa-cut text-blue"></i> <?php echo e(__('Booking')); ?>

                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notification_access')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('notification.index')); ?>">
                    <i class="far fa-bell text-blue"></i> <?php echo e(__('Notification')); ?>

                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report_access')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('report.index')); ?>">
                    <i class="far fa-file-word text-blue"></i> <?php echo e(__('Report')); ?>

                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('custom_notification_access')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('custom.index')); ?>">
                    <i class="fab fa-viber text-blue"></i> <?php echo e(__('Custom Notification')); ?>

                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_access')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('setting.index')); ?>">
                    <i class="far fa-clock text-blue"></i> <?php echo e(__('Setting')); ?>

                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('privacy_access')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('pp')); ?>">
                    <i class="far fa-handshake text-blue"></i> <?php echo e(__('Privacy and Policy')); ?>

                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['review_access','branch_review_access'])): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('review.index')); ?>">
                    <i class="far fa-smile-beam text-blue"></i> <?php echo e(__('Review')); ?>

                </a>
            </li>
            <?php endif; ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>">
                    <i class="ni ni-user-run text-blue"></i> <?php echo e(__('Sign out')); ?>

                </a>
            </li>
          
        </ul>
        <!-- Divider -->
        <hr class="my-3">
        <!-- Heading -->
        
        <!-- Navigation -->
        
    </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\lara\beatybella\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>