

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.header',
array(
'class'=>'info',
'title'=>"Report",'description'=>'',
'icon'=>'fas fa-home',
'breadcrumb'=>array([
'text'=>'Report'
])), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt--7">
    <div class="row">
        <div class="col">
            <div class="card shadow">
                <div class="card-header mb-3">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-1"><?php echo e(__('Report')); ?></h3>
                            
                            <form action="<?php echo e(route('report.create')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-row ">
                                    <div class="form-group col-md-2">
                                        <label for="inputEmail4" class="ul-form__label"><?php echo e(__('From:')); ?></label>
                                        <input type="date" value="<?php echo e($req['from'] ?? ''); ?>" name="from"
                                            class="form-control  <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autofocus>

                                        <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-2">
                                        <label for="inputEmail4" class="ul-form__label"><?php echo e(__('To:')); ?></label>
                                        <input type="date" name="to" value="<?php echo e($req['to'] ?? ''); ?>"
                                            class="form-control  <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                        <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-2">
                                        <label for="inputEmail4" class="ul-form__label"><?php echo e(__('Branch:')); ?></label>
                                        <select class="js-example-basic form-control" name="branch">

                                            <option value="branch_id">All
                                            </option>
                                            <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </select>
                                        <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-2">
                                        <label for="inputEmail4" class="ul-form__label"><?php echo e(__('User:')); ?></label>
                                        <select class="js-example-basic form-control" name="user">

                                            <option value="user_id">All
                                            </option>
                                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </select>
                                        <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-2">
                                        <label for="inputEmail4" class="ul-form__label"><?php echo e(__('Employee:')); ?></label>
                                        <select class="js-example-basic form-control" name="emp">

                                            <option selected value="emp_id">All
                                            </option>
                                            <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </select>

                                    </div>
                                    <div class="form-group col-md-2">
                                        <label for="inputEmail4" class="ul-form__label"><?php echo e(__('Status:')); ?></label>
                                        <select class="js-example-basic form-control" name="status">

                                            <option selected value="status">All
                                            </option>
                                            <option value="1">Confirm
                                            </option>

                                            <option value="0">Waiting
                                            </option>

                                            <option value="2">Complete
                                            </option>

                                            <option value="3">Cancel
                                            </option>



                                        </select>

                                    </div>
                                    <div class="form-group col-md-8" style="margin-top: 32px;">

                                        <button type="submit" class="btn  btn-primary m-1"><?php echo e(__('Search')); ?></button>
                                        <button type="reset" class=" btn   btn-secondary m-1"><?php echo e(__('Reset')); ?></button>

                                    </div>

                                </div>
                            </form>
                        </div>

                    </div>
                </div>

                <div class="col-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('status')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="table-responsive">
                    <table id="dataTable" class="table table-flush" style="width:100%">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
                                <th><?php echo e(__('User Name')); ?></th>
                                <th><?php echo e(__('Branch')); ?></th>
                                <th><?php echo e(__('Booking id')); ?></th>
                                <th><?php echo e(__('Services - Employee')); ?></th>
                                <th><?php echo e(__('Booking Date')); ?></th>
                                <th><?php echo e(__('Status')); ?></th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $master ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->user); ?></td>
                                <td><?php echo e($item->branch); ?></td>
                                <td><?php echo e($item->booking_id); ?></td>
                                <td>
                                    <?php $__currentLoopData = $item->child_booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($cb->service->name .'- ('. $cb->employee->name.')'); ?> ,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                   <?php echo e(date("d-m-Y", strtotime($item->start_time))); ?> 
                                </td>
                                <td>
                                    <?php if($item->status == 1): ?>
                                    <span class="badge   badge-success m-1"><?php echo e(__('Confirm')); ?></span>
                                    <?php elseif($item->status == 0): ?>
                                    <span class="badge   badge-warning  m-1"><?php echo e(__('Waiting')); ?></span>
                                    <?php elseif($item->status == 2): ?>
                                    <span class="badge   badge-default  m-1"><?php echo e(__('Complete')); ?></span>
                                    <?php else: ?>
                                    <span class="badge   badge-danger  m-1"><?php echo e(__('Cancel')); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara\beatybella\resources\views/admin/report/index.blade.php ENDPATH**/ ?>